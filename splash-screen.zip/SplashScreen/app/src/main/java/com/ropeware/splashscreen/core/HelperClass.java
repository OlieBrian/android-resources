package com.ropeware.splashscreen.core;

/** Class that holds custom global methods. **/
public class HelperClass {

    /** Returns App version name. **/
    public static String getAppVersion() {
        return "1.0";
    }
}