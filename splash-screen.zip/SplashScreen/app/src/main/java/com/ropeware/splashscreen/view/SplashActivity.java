package com.ropeware.splashscreen.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.ropeware.splashscreen.R;
import com.ropeware.splashscreen.core.HelperClass;

public class SplashActivity extends AppCompatActivity {

    private int splashTimer = 1000 * 3;
    private TextView splashVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        setSplashScreen();
        switchActivity();
    }

    /** Setup splash screen version text. **/
    private void setSplashScreen() {
        splashVersion = findViewById(R.id.splash_version);
        String text = getString(R.string.splash_version) + " " + HelperClass.getAppVersion();
        splashVersion.setText(text);
    }

    /** Change to Main Activity with a delay. **/
    private void switchActivity() {
        // Handler needed to delay activity change.
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Create intent to change activities.
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, splashTimer);
    }
}