package com.ropeware.database.api;

/** Class that holds custom helping methods. **/
public class HelperClass {

    public static final String TAG = "TAG_LOG";

    /** Returns App version name. **/
    public static String getAppVersion() {
        return "1.0";
    }
}