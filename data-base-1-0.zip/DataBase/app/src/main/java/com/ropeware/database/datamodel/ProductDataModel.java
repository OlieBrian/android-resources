package com.ropeware.database.datamodel;

public class ProductDataModel {
}
