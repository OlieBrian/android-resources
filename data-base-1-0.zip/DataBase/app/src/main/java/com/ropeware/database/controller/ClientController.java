package com.ropeware.database.controller;

import android.util.Log;

import com.ropeware.database.api.HelperClass;

public class ClientController implements ICrud {

    @Override
    public void create() {
        Log.i(HelperClass.TAG, "create: Client");
    }

    @Override
    public void read() {
        Log.i(HelperClass.TAG, "read: Client.");
    }

    @Override
    public void update() {
        Log.i(HelperClass.TAG, "update: Client.");
    }

    @Override
    public void delete() {
        Log.i(HelperClass.TAG, "delete: Client.");
    }
}
