package com.ropeware.database.controller;

import android.util.Log;

import com.ropeware.database.api.HelperClass;

public class ProductController implements ICrud {

    @Override
    public void create() {
        Log.i(HelperClass.TAG, "create: Product");
    }

    @Override
    public void read() {
        Log.i(HelperClass.TAG, "read: Product.");
    }

    @Override
    public void update() {
        Log.i(HelperClass.TAG, "update: Product.");
    }

    @Override
    public void delete() {
        Log.i(HelperClass.TAG, "delete: Product.");
    }
}