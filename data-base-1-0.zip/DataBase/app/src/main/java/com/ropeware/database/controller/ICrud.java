package com.ropeware.database.controller;

public interface ICrud {
    public void create();
    public void read();
    public void update();
    public void delete();
}