package com.ropeware.sharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ropeware.sharedpreferences.R;

public class MainActivity extends AppCompatActivity {

    private static final String PREF_NAME = "APP_PREF";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor data;

    private String productName;
    private int productID;
    private float productPrice;
    private boolean productAvailable;

    private TextView textName;
    private TextView textID;
    private TextView textPrice;
    private TextView textAvailable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSharedPreferences();
        showSharedPreferences();
    }

    /** Set a value to variables and save them into the shared preferences. **/
    private void setSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Start editing data o apply.
        data = sharedPreferences.edit();
        productName = "Real Cat Girl";
        productID = 177013;
        productPrice = 420.69f;
        productAvailable = true;

        // Insert your data.
        data.putString("ProductName", productName);
        data.putInt("ProductID", productID);
        data.putFloat("ProductPrice", productPrice);
        data.putBoolean("ProductAvailable", productAvailable);

        // Finish editing.
        data.apply();
    }

    /** Show shared preferences stored values. **/
    private void showSharedPreferences() {
        // Find text fields.
        textName = findViewById(R.id.main_name);
        textID = findViewById(R.id.main_id);
        textPrice = findViewById(R.id.main_price);
        textAvailable = findViewById(R.id.main_available);

        // Concatenate strings and set them.
        String text0 = "Product: " + sharedPreferences.getString("ProductName", "N/DA");
        String text1 = "ID: " + sharedPreferences.getInt("ProductID", 0);
        String text2 = "Price: " + sharedPreferences.getFloat("ProductPrice", 0);
        String text3 = "Available: " + sharedPreferences.getBoolean("ProductAvailable", false);
        textName.setText(text0);
        textID.setText(text1);
        textPrice.setText(text2);
        textAvailable.setText(text3);
    }
}